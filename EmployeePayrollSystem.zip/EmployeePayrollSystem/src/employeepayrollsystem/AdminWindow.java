package employeepayrollsystem;

import java.awt.CardLayout;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JTextField;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class AdminWindow extends javax.swing.JFrame {
    CardLayout cards;
    ArrayList<String> posts;
    ArrayList<Integer> salaries;
    int []noofemployees;
    int totalexpense;
    public AdminWindow() {
        initComponents();
        lbl_budget.setText("Budget : "+getBudget()+" MYR");
        getPosts();
        getEmployees();
        cards = (CardLayout)(pnl_background.getLayout());
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DialogBox = new javax.swing.JDialog();
        lbl_message = new javax.swing.JLabel();
        btn_ok = new javax.swing.JButton();
        pnl_dock = new javax.swing.JPanel();
        btn_view = new javax.swing.JButton();
        btn_addemp = new javax.swing.JButton();
        btn_checkrecord = new javax.swing.JButton();
        btn_adddesignation = new javax.swing.JButton();
        pnl_background = new javax.swing.JPanel();
        pnl_view = new javax.swing.JPanel();
        pnl_employees = new javax.swing.JPanel();
        lbl_employees = new javax.swing.JLabel();
        pnl_budget = new javax.swing.JPanel();
        lbl_budget = new javax.swing.JLabel();
        pnl_expense = new javax.swing.JPanel();
        lbl_expense = new javax.swing.JLabel();
        btn_pay = new javax.swing.JButton();
        lbl_date = new javax.swing.JLabel();
        txt_upbudget = new javax.swing.JTextField();
        lbl_upbudget = new javax.swing.JLabel();
        btn_update = new javax.swing.JButton();
        pnl_addemp = new javax.swing.JPanel();
        lbl_heading = new javax.swing.JLabel();
        lbl_name = new javax.swing.JLabel();
        txt_name = new javax.swing.JTextField();
        lbl_empid = new javax.swing.JLabel();
        txt_empid = new javax.swing.JTextField();
        lbl_address = new javax.swing.JLabel();
        txt_address = new javax.swing.JTextField();
        lbl_dob = new javax.swing.JLabel();
        dc_dob = new com.toedter.calendar.JDateChooser();
        lbl_doj = new javax.swing.JLabel();
        dc_doj = new com.toedter.calendar.JDateChooser();
        lbl_designation = new javax.swing.JLabel();
        cb_designation = new javax.swing.JComboBox<>();
        lbl_accountno = new javax.swing.JLabel();
        txt_accountno = new javax.swing.JTextField();
        btn_add = new javax.swing.JButton();
        pnl_checkrecord = new javax.swing.JPanel();
        sp_tablecontainer = new javax.swing.JScrollPane();
        tbl_details = new javax.swing.JTable();
        pnl_adddesignation = new javax.swing.JPanel();
        lbl_post = new javax.swing.JLabel();
        txt_post = new javax.swing.JTextField();
        lbl_salary = new javax.swing.JLabel();
        txt_salary = new javax.swing.JTextField();
        btn_addpost = new javax.swing.JButton();

        DialogBox.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        DialogBox.setTitle("Message");
        DialogBox.setLocation(new java.awt.Point(640, 320));
        DialogBox.setResizable(false);
        DialogBox.setSize(new java.awt.Dimension(400, 120));

        lbl_message.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_message.setText("Some Message Here");

        btn_ok.setText("OK");
        btn_ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_okActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout DialogBoxLayout = new javax.swing.GroupLayout(DialogBox.getContentPane());
        DialogBox.getContentPane().setLayout(DialogBoxLayout);
        DialogBoxLayout.setHorizontalGroup(
            DialogBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DialogBoxLayout.createSequentialGroup()
                .addGroup(DialogBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(DialogBoxLayout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(btn_ok))
                    .addGroup(DialogBoxLayout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(lbl_message, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(93, Short.MAX_VALUE))
        );
        DialogBoxLayout.setVerticalGroup(
            DialogBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DialogBoxLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(lbl_message)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_ok)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Emloyee Payroll System");
        setBounds(new java.awt.Rectangle(640, 300, 628, 0));
        setLocation(new java.awt.Point(640, 300));

        pnl_dock.setBackground(new java.awt.Color(0, 0, 0));

        btn_view.setText("View");
        btn_view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_viewActionPerformed(evt);
            }
        });

        btn_addemp.setText("Add Employee");
        btn_addemp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addempActionPerformed(evt);
            }
        });

        btn_checkrecord.setText("Check Record");
        btn_checkrecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_checkrecordActionPerformed(evt);
            }
        });

        btn_adddesignation.setText("Add Designation");
        btn_adddesignation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_adddesignationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_dockLayout = new javax.swing.GroupLayout(pnl_dock);
        pnl_dock.setLayout(pnl_dockLayout);
        pnl_dockLayout.setHorizontalGroup(
            pnl_dockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_dockLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_dockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_addemp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_adddesignation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_checkrecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnl_dockLayout.setVerticalGroup(
            pnl_dockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_dockLayout.createSequentialGroup()
                .addGap(152, 152, 152)
                .addComponent(btn_view)
                .addGap(54, 54, 54)
                .addComponent(btn_addemp)
                .addGap(54, 54, 54)
                .addComponent(btn_adddesignation)
                .addGap(54, 54, 54)
                .addComponent(btn_checkrecord)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnl_background.setBackground(new java.awt.Color(255, 255, 255));
        pnl_background.setLayout(new java.awt.CardLayout());

        pnl_view.setBackground(new java.awt.Color(255, 255, 255));

        pnl_employees.setBackground(new java.awt.Color(255, 255, 255));
        pnl_employees.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        lbl_employees.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_employees.setText("No. of Employees");
        lbl_employees.setToolTipText("");
        lbl_employees.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        javax.swing.GroupLayout pnl_employeesLayout = new javax.swing.GroupLayout(pnl_employees);
        pnl_employees.setLayout(pnl_employeesLayout);
        pnl_employeesLayout.setHorizontalGroup(
            pnl_employeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_employeesLayout.createSequentialGroup()
                .addComponent(lbl_employees, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnl_employeesLayout.setVerticalGroup(
            pnl_employeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_employeesLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(lbl_employees, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnl_budget.setBackground(new java.awt.Color(255, 255, 255));
        pnl_budget.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        lbl_budget.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_budget.setText("Budget");
        lbl_budget.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        javax.swing.GroupLayout pnl_budgetLayout = new javax.swing.GroupLayout(pnl_budget);
        pnl_budget.setLayout(pnl_budgetLayout);
        pnl_budgetLayout.setHorizontalGroup(
            pnl_budgetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_budgetLayout.createSequentialGroup()
                .addComponent(lbl_budget, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnl_budgetLayout.setVerticalGroup(
            pnl_budgetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_budgetLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(lbl_budget, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnl_expense.setBackground(new java.awt.Color(255, 255, 255));
        pnl_expense.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        lbl_expense.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_expense.setText("Total Expense");
        lbl_expense.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        javax.swing.GroupLayout pnl_expenseLayout = new javax.swing.GroupLayout(pnl_expense);
        pnl_expense.setLayout(pnl_expenseLayout);
        pnl_expenseLayout.setHorizontalGroup(
            pnl_expenseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 173, Short.MAX_VALUE)
            .addGroup(pnl_expenseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnl_expenseLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lbl_expense, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        pnl_expenseLayout.setVerticalGroup(
            pnl_expenseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 75, Short.MAX_VALUE)
            .addGroup(pnl_expenseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnl_expenseLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lbl_expense, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        btn_pay.setText("Pay");
        btn_pay.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        btn_pay.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btn_pay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_payActionPerformed(evt);
            }
        });

        lbl_date.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        txt_upbudget.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_upbudgetKeyPressed(evt);
            }
        });

        lbl_upbudget.setText("Update Budget");

        btn_update.setText("Update");
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_viewLayout = new javax.swing.GroupLayout(pnl_view);
        pnl_view.setLayout(pnl_viewLayout);
        pnl_viewLayout.setHorizontalGroup(
            pnl_viewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_viewLayout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(pnl_viewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_viewLayout.createSequentialGroup()
                        .addComponent(lbl_upbudget)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_viewLayout.createSequentialGroup()
                        .addComponent(lbl_date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_viewLayout.createSequentialGroup()
                        .addGroup(pnl_viewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_upbudget, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnl_viewLayout.createSequentialGroup()
                                .addGroup(pnl_viewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(pnl_budget, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pnl_employees, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(pnl_viewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(pnl_expense, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_pay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(55, 55, 55))))
            .addGroup(pnl_viewLayout.createSequentialGroup()
                .addGap(203, 203, 203)
                .addComponent(btn_update)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnl_viewLayout.setVerticalGroup(
            pnl_viewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_viewLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_date, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(105, 105, 105)
                .addGroup(pnl_viewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnl_employees, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnl_expense, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(pnl_viewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_pay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnl_budget, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(29, 29, 29)
                .addComponent(lbl_upbudget)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_upbudget, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_update)
                .addContainerGap(149, Short.MAX_VALUE))
        );

        lbl_date.setText(""+LocalDate.now());

        pnl_background.add(pnl_view, "viewcard");

        pnl_addemp.setBackground(new java.awt.Color(255, 255, 255));

        lbl_heading.setFont(new java.awt.Font("Helvetica Neue", 0, 24)); // NOI18N
        lbl_heading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_heading.setText("Enter Employee Details");

        lbl_name.setText("Enter Name");

        lbl_empid.setText("Enter Employee ID");

        txt_empid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_empidKeyPressed(evt);
            }
        });

        lbl_address.setText("Enter Address");

        lbl_dob.setText("Select Date of Birth");

        lbl_doj.setText("Select Date of Joining");

        lbl_designation.setText("Select Designation");

        lbl_accountno.setText("Enter Account No");

        txt_accountno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_accountnoKeyPressed(evt);
            }
        });

        btn_add.setText("Add");
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_addempLayout = new javax.swing.GroupLayout(pnl_addemp);
        pnl_addemp.setLayout(pnl_addempLayout);
        pnl_addempLayout.setHorizontalGroup(
            pnl_addempLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_addempLayout.createSequentialGroup()
                .addGroup(pnl_addempLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_addempLayout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(lbl_heading, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnl_addempLayout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(pnl_addempLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_name)
                            .addComponent(lbl_name)
                            .addComponent(txt_empid, javax.swing.GroupLayout.DEFAULT_SIZE, 392, Short.MAX_VALUE)
                            .addComponent(lbl_empid)
                            .addComponent(lbl_address)
                            .addComponent(txt_address, javax.swing.GroupLayout.DEFAULT_SIZE, 392, Short.MAX_VALUE)
                            .addComponent(lbl_dob)
                            .addComponent(dc_dob, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl_doj)
                            .addComponent(dc_doj, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl_designation)
                            .addComponent(cb_designation, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl_accountno)
                            .addComponent(txt_accountno, javax.swing.GroupLayout.DEFAULT_SIZE, 392, Short.MAX_VALUE))))
                .addContainerGap(41, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_addempLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btn_add, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnl_addempLayout.setVerticalGroup(
            pnl_addempLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_addempLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lbl_heading, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_name)
                .addGap(3, 3, 3)
                .addComponent(txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_empid)
                .addGap(1, 1, 1)
                .addComponent(txt_empid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_accountno)
                .addGap(1, 1, 1)
                .addComponent(txt_accountno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_address)
                .addGap(1, 1, 1)
                .addComponent(txt_address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_dob)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dc_dob, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_doj)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dc_doj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_designation)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cb_designation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_add)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        pnl_background.add(pnl_addemp, "addcard");

        pnl_checkrecord.setBackground(new java.awt.Color(255, 255, 255));

        tbl_details.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tbl_details.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Emp_ID", "Name", "Acc. No", "Designation", "Salary", "Birth Date", "Join Date", "Address"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Long.class, java.lang.String.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        sp_tablecontainer.setViewportView(tbl_details);

        javax.swing.GroupLayout pnl_checkrecordLayout = new javax.swing.GroupLayout(pnl_checkrecord);
        pnl_checkrecord.setLayout(pnl_checkrecordLayout);
        pnl_checkrecordLayout.setHorizontalGroup(
            pnl_checkrecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sp_tablecontainer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)
        );
        pnl_checkrecordLayout.setVerticalGroup(
            pnl_checkrecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sp_tablecontainer, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        pnl_background.add(pnl_checkrecord, "checkrecordcard");

        pnl_adddesignation.setBackground(new java.awt.Color(255, 255, 255));

        lbl_post.setText("Enter Post Name");

        lbl_salary.setText("Enter Salary for the Post");

        txt_salary.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_salaryKeyPressed(evt);
            }
        });

        btn_addpost.setText("Add");
        btn_addpost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addpostActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_adddesignationLayout = new javax.swing.GroupLayout(pnl_adddesignation);
        pnl_adddesignation.setLayout(pnl_adddesignationLayout);
        pnl_adddesignationLayout.setHorizontalGroup(
            pnl_adddesignationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_adddesignationLayout.createSequentialGroup()
                .addContainerGap(54, Short.MAX_VALUE)
                .addGroup(pnl_adddesignationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_salary)
                    .addComponent(lbl_post)
                    .addComponent(txt_post, javax.swing.GroupLayout.DEFAULT_SIZE, 376, Short.MAX_VALUE)
                    .addComponent(txt_salary))
                .addGap(54, 54, 54))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_adddesignationLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_addpost, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnl_adddesignationLayout.setVerticalGroup(
            pnl_adddesignationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_adddesignationLayout.createSequentialGroup()
                .addGap(229, 229, 229)
                .addComponent(lbl_post)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_post, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_salary)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_salary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_addpost)
                .addContainerGap(226, Short.MAX_VALUE))
        );

        pnl_background.add(pnl_adddesignation, "designationcard");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(pnl_dock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnl_background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnl_background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnl_dock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_viewActionPerformed
        cards.show(pnl_background, "viewcard");
        getEmployees();
    }//GEN-LAST:event_btn_viewActionPerformed

    private void btn_addempActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addempActionPerformed
        getPosts();
        cards.show(pnl_background, "addcard");
    }//GEN-LAST:event_btn_addempActionPerformed

    private void btn_checkrecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_checkrecordActionPerformed
        cards.show(pnl_background, "checkrecordcard");
        getEmployees();
    }//GEN-LAST:event_btn_checkrecordActionPerformed

    private void txt_accountnoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_accountnoKeyPressed
        numInput(txt_accountno,evt);
    }//GEN-LAST:event_txt_accountnoKeyPressed

    private void txt_empidKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_empidKeyPressed
        numInput(txt_empid,evt);
    }//GEN-LAST:event_txt_empidKeyPressed

    private void btn_adddesignationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_adddesignationActionPerformed
        cards.show(pnl_background, "designationcard");
    }//GEN-LAST:event_btn_adddesignationActionPerformed

    private void btn_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_okActionPerformed
        DialogBox.dispose();
    }//GEN-LAST:event_btn_okActionPerformed

    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
        addEmployees();
    }//GEN-LAST:event_btn_addActionPerformed

    private void btn_addpostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addpostActionPerformed
        addPosts();
    }//GEN-LAST:event_btn_addpostActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        updateBudget(Integer.parseInt(txt_upbudget.getText()));
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_payActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_payActionPerformed
        paySalary();
    }//GEN-LAST:event_btn_payActionPerformed

    private void txt_upbudgetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_upbudgetKeyPressed
        numInput(txt_upbudget,evt);
    }//GEN-LAST:event_txt_upbudgetKeyPressed

    private void txt_salaryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_salaryKeyPressed
        numInput(txt_salary,evt);
    }//GEN-LAST:event_txt_salaryKeyPressed

    private void addEmployees(){
        Employee emp=new Employee();
        if(txt_name.getText().isEmpty() || txt_address.getText().isEmpty() || txt_empid.getText().isEmpty() || txt_accountno.getText().isEmpty() || dc_dob.getDate()==null || dc_doj.getDate()==null){
            lbl_message.setText("Enter All Details!");
            DialogBox.show();        
        }
        else{
            emp.setName(txt_name.getText());
            if(txt_empid.getText().length()==4 && txt_accountno.getText().length()==11){
                emp.setAccno(Long.parseLong(txt_accountno.getText()));
                emp.setAddress(txt_address.getText());
                emp.setEmpid(Integer.parseInt(txt_empid.getText()));
                emp.setDob(new Date(dc_dob.getDate().getDate(),dc_dob.getDate().getMonth()+1,dc_dob.getDate().getYear()+1900));
                emp.setDoj(new Date(dc_doj.getDate().getDate(),dc_doj.getDate().getMonth()+1,dc_doj.getDate().getYear()+1900));
                emp.setDesignation(cb_designation.getSelectedItem().toString());
                emp.setSalary(salaries.get(posts.indexOf(emp.getDesignation())));
                BufferedWriter bw=null;            
                try {
                    bw= new BufferedWriter(new FileWriter("src/files/employees.txt",true));
                    bw.write(emp.getEmpid()+","+emp.getName()+","+emp.getAccno()+","+emp.getDesignation()+","+emp.getSalary()+","+emp.getDob()+","+emp.getDoj()+","+emp.getAddress()+"\n");
                    lbl_message.setText("Employee Added Succesfuly!");
                    DialogBox.show();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                finally{
                    try {
                        bw.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
            else{
                lbl_message.setText("Enter Correct ID and Account No.");
                DialogBox.show();
            }

        }
    }
    
    private void getEmployees(){
        totalexpense=0;
        noofemployees=new int[posts.size()];
        BufferedReader br=null;
        DefaultTableModel model= (DefaultTableModel) tbl_details.getModel();
        model.setRowCount(0);
        int count=0;
        try {
            br=new BufferedReader(new FileReader("src/files/employees.txt"));
            String []emp;
            while(br.ready()){
                emp=br.readLine().split(",");
                model.addRow(new Object[]{emp[0], emp[1], emp[2],emp[3],emp[4],emp[5],emp[6],emp[7]});
                noofemployees[posts.indexOf(emp[3])]+=1;
                
            }
            for (int i = 0; i < salaries.size(); i++) {
                totalexpense+=(salaries.get(i)*noofemployees[i]);
            }
            lbl_expense.setText("Expense : "+totalexpense+" MYR");
            lbl_employees.setText("No of Employees : "+model.getRowCount());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        finally{
            try {
                br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    
    
    }
    
    private void addPosts(){
        BufferedWriter bw=null;
            try {
                bw=new BufferedWriter(new FileWriter("src/files/posts.txt",true));
                bw.write(txt_post.getText()+","+txt_salary.getText()+"\n");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            finally{
                try {
                    bw.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }       
        lbl_message.setText("Post Added Succesfuly!");
        DialogBox.show();
    }
    
    private void getPosts(){
        cb_designation.removeAllItems();
        posts=new ArrayList();
        salaries=new ArrayList();
        BufferedReader br=null;
        try {
            br=new BufferedReader(new FileReader("src/files/posts.txt"));
            String check[];
            while(br.ready()){
                check=br.readLine().split(",");
                posts.add(check[0]);
                salaries.add(Integer.valueOf(check[1]));
            }
            for (int i = 0; i < posts.size(); i++) {
                cb_designation.addItem(posts.get(i));
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        finally{
            try {
                br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private void updateBudget(int budget){
        BufferedWriter bw=null;
        try {
            bw=new BufferedWriter(new FileWriter("src/files/budget.txt"));
            bw.write(""+budget);
        } catch (IOException ex) {
            Logger.getLogger(AdminWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            try {
                bw.close();
                lbl_budget.setText("Budget : "+getBudget()+" MYR");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    
    }
    
    private int getBudget(){
        BufferedReader br=null;
        int budget=0;
        try {
            br = new BufferedReader(new FileReader("src/files/budget.txt"));
            budget=Integer.parseInt(br.readLine());
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        finally{
            try {
                br.close();
            } catch (IOException ex) {
                Logger.getLogger(AdminWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
            return budget;
        }
    
    }
    
    private void paySalary(){
        int budget=getBudget();
        if(budget>=totalexpense){
            budget-=totalexpense;
        }
        else{
            lbl_message.setText("Insufficient Budget!");
            DialogBox.show();
        }
        updateBudget(budget);
    }
    
    private void numInput(JTextField txt,KeyEvent evt){
            if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' || evt.getKeyChar()=='\b') {
            txt.setEditable(true);
        }
        else {
            txt.setEditable(false);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDialog DialogBox;
    private javax.swing.JButton btn_add;
    private javax.swing.JButton btn_adddesignation;
    private javax.swing.JButton btn_addemp;
    private javax.swing.JButton btn_addpost;
    private javax.swing.JButton btn_checkrecord;
    private javax.swing.JButton btn_ok;
    private javax.swing.JButton btn_pay;
    private javax.swing.JButton btn_update;
    private javax.swing.JButton btn_view;
    private javax.swing.JComboBox<String> cb_designation;
    private com.toedter.calendar.JDateChooser dc_dob;
    private com.toedter.calendar.JDateChooser dc_doj;
    private javax.swing.JLabel lbl_accountno;
    private javax.swing.JLabel lbl_address;
    private javax.swing.JLabel lbl_budget;
    private javax.swing.JLabel lbl_date;
    private javax.swing.JLabel lbl_designation;
    private javax.swing.JLabel lbl_dob;
    private javax.swing.JLabel lbl_doj;
    private javax.swing.JLabel lbl_empid;
    private javax.swing.JLabel lbl_employees;
    private javax.swing.JLabel lbl_expense;
    private javax.swing.JLabel lbl_heading;
    private javax.swing.JLabel lbl_message;
    private javax.swing.JLabel lbl_name;
    private javax.swing.JLabel lbl_post;
    private javax.swing.JLabel lbl_salary;
    private javax.swing.JLabel lbl_upbudget;
    private javax.swing.JPanel pnl_adddesignation;
    private javax.swing.JPanel pnl_addemp;
    private javax.swing.JPanel pnl_background;
    private javax.swing.JPanel pnl_budget;
    private javax.swing.JPanel pnl_checkrecord;
    private javax.swing.JPanel pnl_dock;
    private javax.swing.JPanel pnl_employees;
    private javax.swing.JPanel pnl_expense;
    private javax.swing.JPanel pnl_view;
    private javax.swing.JScrollPane sp_tablecontainer;
    private javax.swing.JTable tbl_details;
    private javax.swing.JTextField txt_accountno;
    private javax.swing.JTextField txt_address;
    private javax.swing.JTextField txt_empid;
    private javax.swing.JTextField txt_name;
    private javax.swing.JTextField txt_post;
    private javax.swing.JTextField txt_salary;
    private javax.swing.JTextField txt_upbudget;
    // End of variables declaration//GEN-END:variables
}
