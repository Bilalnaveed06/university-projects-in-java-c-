package employeepayrollsystem;


public class Employee{
    private String name,address,designation;
    private Date dob,doj;
    private long accno;
    private int empid,salary;
    
    public Employee(){}
            
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDob() {
        return dob.getDate();
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getDoj() {
        return doj.getDate();
    }

    public void setDoj(Date doj) {
        this.doj = doj;
    }

    public long getAccno() {
        return accno;
    }

    public void setAccno(long accno) {
        this.accno = accno;
    }

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }
    
    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }
    
    
}
